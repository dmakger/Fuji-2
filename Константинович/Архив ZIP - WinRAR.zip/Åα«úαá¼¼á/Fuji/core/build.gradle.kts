apply {
    from("$rootDir/library-build.gradle")
}

dependencies {
}