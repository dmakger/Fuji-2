package com.clownteam.core.domain

interface StateHolder<T> {
    val state: T
}