package com.clownteam.core.utils

fun printLogD(message: String, tag: String = "debugTag") {
    println("$tag: $message")
}