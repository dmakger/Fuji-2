package com.clownteam.authorization_datasource

class MyClass {
}