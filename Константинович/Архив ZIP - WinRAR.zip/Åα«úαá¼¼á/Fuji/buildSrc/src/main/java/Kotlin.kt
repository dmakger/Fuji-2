object Kotlin {
    const val version = "1.6.10"
}