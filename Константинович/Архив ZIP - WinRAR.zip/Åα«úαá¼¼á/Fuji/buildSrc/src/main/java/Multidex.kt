object Multidex {
    private const val version = "2.0.1"
    const val multidex = "androidx.multidex:multidex:$version"
}
