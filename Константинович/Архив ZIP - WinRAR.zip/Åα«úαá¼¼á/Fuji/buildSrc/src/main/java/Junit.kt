object Junit {
    private const val version = "4.13.2"
    const val junit4 = "junit:junit:$version"
}