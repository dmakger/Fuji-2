object Mockito {
    private const val version = "4.0.0"
    const val mockitoKotlin = "org.mockito.kotlin:mockito-kotlin:$version"

    const val mockitoAndroid = "org.mockito:mockito-android:$version"
}