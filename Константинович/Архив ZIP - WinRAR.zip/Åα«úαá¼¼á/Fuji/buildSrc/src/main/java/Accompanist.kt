object Accompanist {
    private const val animationsVersion = "0.23.1"
    const val animations = "com.google.accompanist:accompanist-navigation-animation:$animationsVersion"
}