object Testing {
    private const val coroutinesVersion="1.4.2"
    const val coroutines = "org.jetbrains.kotlinx:kotlinx-coroutines-test:$coroutinesVersion"

    private const val coreTestingVersion = "2.1.0"
    const val coreTesting = "androidx.arch.core:core-testing:$coreTestingVersion"
}