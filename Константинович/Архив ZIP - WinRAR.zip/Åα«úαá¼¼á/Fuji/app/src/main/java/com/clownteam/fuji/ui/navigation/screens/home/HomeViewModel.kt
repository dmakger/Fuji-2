package com.clownteam.fuji.ui.navigation.screens.home

import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {
}