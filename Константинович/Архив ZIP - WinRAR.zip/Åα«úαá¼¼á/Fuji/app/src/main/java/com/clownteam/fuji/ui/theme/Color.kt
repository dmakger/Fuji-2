package com.clownteam.fuji.ui.theme

import androidx.compose.ui.graphics.Color

val Purple = Color(0xFF7B61FF)
val DarkGray = Color(0xFF282828)

val BlackLight1 = Color(0xFF1A1A1A)
val BlackLight2 = Color(0xFF1F1F1F)
val BlackLight3 = Color(0xFF282828)

val RedErrorDark = Color(0xFFB00020)
val RedErrorLight = Color(0xFFEF5350)